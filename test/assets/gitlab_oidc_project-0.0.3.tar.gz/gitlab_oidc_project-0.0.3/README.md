# GitLab OIDC Project

<!--- BADGES: START --->
[![CI](https://github.com/trailofbits/gitlab-oidc-project/actions/workflows/tests.yml/badge.svg)](https://github.com/trailofbits/gitlab-oidc-project/actions/workflows/tests.yml)
[![PyPI version](https://badge.fury.io/py/gitlab-oidc-project.svg)](https://pypi.org/project/gitlab-oidc-project)
[![Packaging status](https://repology.org/badge/tiny-repos/python:gitlab-oidc-project.svg)](https://repology.org/project/python:gitlab-oidc-project/versions)
<!--- BADGES: END --->


