"""The `gitlab-oidc-project` APIs."""

__version__ = "0.0.3"
