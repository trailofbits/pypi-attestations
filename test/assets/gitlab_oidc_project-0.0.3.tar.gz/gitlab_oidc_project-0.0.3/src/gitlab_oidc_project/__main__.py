"""The `python -m gitlab-oidc-project` entrypoint."""

if __name__ == "__main__":  # pragma: no cover
    from gitlab_oidc_project._cli import main

    main()
