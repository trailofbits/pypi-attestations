"""The `gitlab-oidc-project` entrypoint."""


def main() -> None:
    print("Hello, world!")
