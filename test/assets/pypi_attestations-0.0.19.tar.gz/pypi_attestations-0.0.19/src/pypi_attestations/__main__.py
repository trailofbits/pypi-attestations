"""The pypi-attestations entrypoint."""

if __name__ == "__main__":
    from pypi_attestations._cli import main

    main()
